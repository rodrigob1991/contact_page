#!/bin/bash

npm install -g corepack
corepack enable
corepack enable yarn
