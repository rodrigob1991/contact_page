#!/bin/bash

killall nginx
