"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isNonEmpty = void 0;
const isNonEmpty = (a) => a.length > 0;
exports.isNonEmpty = isNonEmpty;
