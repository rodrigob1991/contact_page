"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.id = exports.crlf = void 0;
exports.crlf = "\r\n";
exports.id = "HTTP";
