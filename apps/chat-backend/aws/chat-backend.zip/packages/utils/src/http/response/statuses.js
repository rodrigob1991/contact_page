"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.statuses = void 0;
exports.statuses = {
    400: "Bad Request",
    401: "Unauthorized",
    500: "Internal Server Error"
};
