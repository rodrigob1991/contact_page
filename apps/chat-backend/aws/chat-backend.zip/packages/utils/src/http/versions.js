"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.versions = void 0;
exports.versions = {
    "1.1": "1.1", "2.0": "2.0", "3.0": "3.0"
};
